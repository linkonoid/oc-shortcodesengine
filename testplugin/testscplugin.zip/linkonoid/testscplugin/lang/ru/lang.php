<?php return [

    'plugin' => [           
        'name' =>'TestSCplugin',
        'description' => 'Пример плагина для движка шорткодов',        
        'settings' => [
            'label' => 'Настройки TestSCplugin',            
            'description' => 'Конфигурация и настройка TestSCplugin',
            'category' => 'Короткие коды',
            'keywords' => 'shortcodes, short, code, engine, BBCode, plugin, settings',
            'permissions' => [
                'tab'   => 'Разрешения для TestSCplugin',
                'label' => 'Показывать вкладку настроек TestSCplugin в панели администрирования', 
            ],  
        ],
    ],
    
];
