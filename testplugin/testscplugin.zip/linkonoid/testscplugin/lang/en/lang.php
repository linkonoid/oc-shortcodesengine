<?php return [

    'plugin' => [           
        'name' =>'TestSCplugin',
        'description' => 'Example TestSCplugin for ShortcodesEngine plugin',        
        'settings' => [
            'label' => 'TestSCplugin settings',            
            'description' => 'Example TestSCplugin for ShortcodesEngine plugin',
            'category' => 'Shortcodes',
            'keywords' => 'shortcodes, short, code, engine, BBCode, plugin, settings',
            'permissions' => [
                'tab'   => 'Permissions for TestSCplugin plugin settings',
                'label' => 'Show TestSCplugin plugin settings tab in control panel', 
            ],  
        ],
    ],
     
];