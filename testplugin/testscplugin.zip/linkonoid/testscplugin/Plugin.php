<?php namespace Linkonoid\TestSCplugin;

use Event;
use System\Classes\PluginBase;
use System\Classes\SettingsManager;

/**
 * @package linkonoid\testscplugin
 * @author Max Barulin (https://github.com/linkonoid)
 */ 

class Plugin extends PluginBase
{	    

    public function pluginDetails()
    {
        return [
            'name' => 'TestSCplugin',
            'description' => 'Example TestSCplugin for ShortcodesEngine plugin',
            'author' => 'Linkonoid',
			'icon' => 'icon-code',
			'homepage'    => 'https://github.com/linkonoid'
        ];
    }

    public function registerPermissions()
    {      
 		return [
            'linkonoid.shortcodeengine.access_meta'  => [
                'tab'   => 'linkonoid.testscplugin::lang.plugin.settings.permissions.tab',
                'label' => 'linkonoid.testscplugin::lang.plugin.settings.permissions.label',
			],
        ];
    }

    public function registerSettings()
    {	
        return [
            'settings' => [
                'label' => 'linkonoid.testscplugin::lang.plugin.settings.label',
                'description' => 'linkonoid.testscplugin::lang.plugin.settings.description',
                'category' => 'linkonoid.testscplugin::lang.plugin.settings.category',
                'icon' => 'icon-code',
                'class' => 'Linkonoid\TestSCplugin\Models\Settings',
				'keywords' => 'linkonoid.testscplugin::lang.plugin.settings.keywords',
                'order' => 550,               
                'permissions' => ['linkonoid.testscplugin.access_settings']
            ]
        ];
	}

	public function boot()
    {    
        Event::listen('linkonoid.shortcodesengine.onshortcodeHandlers', function ($shortcodes) {
            return $shortcodes->registerAllshortcodes(__DIR__.'/shortcodes',$shortcodes);            
        });
    }
       
}
